# DAM-ServeisProcessos

Aquest repositori conté arxius de teoria i exercicis per a l'assignatura de Serveis i Processos.

Els arxius '.md' es poden visualitzar amb Visual Studio Code, o qualsevol visor 'Markdown'