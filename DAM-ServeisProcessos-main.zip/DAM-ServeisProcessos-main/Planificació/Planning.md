```text
13/09 Processos
20/09 Processos

27/09 Sincronització
04/10 Sockets

11/10 Sockets
18/10 Sockets
25/10 Preparació projecte (TPV comandes Bar)

06/11 - 27/11 Projecte 1

22/11 Servidors
29/11 Servidors
13/11 Servidors
10/01 Preparació projecte

22/01 - 12/02 Projecte 2

17/01 IA
24/01 IA
31/01 IA
07/02 IA
21/02 IA
28/02 IA
07/03 Seguretat
14/03 Seguretat

26/03 - 09/04 Projecte 3
```